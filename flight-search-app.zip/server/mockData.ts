// export const mockAirportRequestData = [
//     {
//         DepartureAirportCode: 'MEl',
//         ArrivalAirportCode: 'LHR',
//         DepartureDate: '2019-11-22T00:00:00+11:00',
//         ReturnDate: '2019-11-23T00:00:00+11:00'
//     },
//     {
//         DepartureAirportCode: 'SYD',
//         ArrivalAirportCode: 'DEL',
//         DepartureDate: '2019-11-25T00:00:00+11:00',
//         ReturnDate: '2019-11-26T00:00:00+11:00'
//     },
//     {
//         DepartureAirportCode: 'SYD',
//         ArrivalAirportCode: 'MEL',
//         DepartureDate: '2019-11-28T00:00:00+11:00',
//         ReturnDate: '2019-11-29T00:00:00+11:00'
//     }
// ];

// export const mockAirlines = [
//     {
//         AirlineName: 'China Southern Airlines',
//         logo: 'http://nmflightapi.azurewebsites.net/Images/AirlineLogo/CZ.gif'
//     },
//     {
//         AirlineName: 'Emirates Airline',
//         logo: 'http://nmflightapi.azurewebsites.net/Images/AirlineLogo/EK.gif'
//     },
//     {
//         AirlineName: 'Multi',
//         logo: 'http://nmflightapi.azurewebsites.net/Images/AirlineLogo/MultiAirline.gif'
//     }
// ];
