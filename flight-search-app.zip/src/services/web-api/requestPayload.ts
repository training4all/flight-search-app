export interface IRequestPayload {
    DepartureAirportCode: string;
    ArrivalAirportCode: string;
    DepartureDate: string;
    ReturnDate: string;
}
